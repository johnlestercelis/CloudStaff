//
//  ViewController.swift
//  TestCloudStaff
//
//  Created by John Lester Celis on 3/6/20.
//  Copyright © 2020 John Lester Celis. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UITableViewController {
    let mf = MeasurementFormatter()
     var timer = Timer()
    var selectedCity: String?
    var arrayTobeSaved = [String]()
    private var searchResults = [JSON]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)
    private let apiFetcher = APITask()
    private var previousRun = Date()
    private let minInterval = 0.05
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       tableView.tableFooterView = UIView()
       tableView.keyboardDismissMode = .onDrag
       setupTableViewBackgroundView()
       setupSearchBar()
        
        if let city = selectedCity, city.count != 0 {
            fetchResults(for: city)
            tableView.reloadData()
        }
        
        if self.isKeyPresentInUserDefaults(key: "RecentSearch") {
            arrayTobeSaved = UserDefaults.standard.object(forKey: "RecentSearch") as! [String]
        }
    }
    
    private func setupTableViewBackgroundView() {
        let backgroundViewLabel = UILabel(frame: .zero)
        backgroundViewLabel.textColor = .darkGray
        backgroundViewLabel.numberOfLines = 0
        if let city = selectedCity, city.count == 0 {
            backgroundViewLabel.text = " Oops, No results to show "
        }
        backgroundViewLabel.textAlignment = NSTextAlignment.center
        backgroundViewLabel.font.withSize(20)
        tableView.backgroundView = backgroundViewLabel
    }

    private func setupSearchBar() {
        searchController.searchBar.delegate = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.placeholder = "Search any City"
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
    }
    
    @objc func output() {
           
           if timer.userInfo != nil {
            print(timer.userInfo!)
            if Date().timeIntervalSince(previousRun) > minInterval {
                previousRun = Date()
                fetchResults(for: timer.userInfo! as! String)
                
                if arrayTobeSaved.count <= 10 && !arrayTobeSaved.contains(timer.userInfo! as! String) {
                    arrayTobeSaved.append(timer.userInfo! as! String)
                } else {
                    for (index, value) in arrayTobeSaved.enumerated() {
                        if value == timer.userInfo! as! String {
                            arrayTobeSaved.move(at: index, to: 0)
                            break
                        }
                    }
                }
                UserDefaults.standard.set(arrayTobeSaved, forKey: "RecentSearch")
               }
           }
           timer.invalidate()
       }
    
    func convertTemp(temp: Double, from inputTempType: UnitTemperature, to outputTempType: UnitTemperature) -> String {
         mf.numberFormatter.maximumFractionDigits = 0
         mf.unitOptions = .providedUnit
         let input = Measurement(value: temp, unit: inputTempType)
         let output = input.converted(to: outputTempType)
         return mf.string(from: output)
       }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
           // #warning Incomplete implementation, return the number of sections
           return 1
       }

       override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           // #warning Incomplete implementation, return the number of rows
           return searchResults.count
       }

       
       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? CustomTableViewCell {
            
            if let temp = searchResults[indexPath.row]["main"]["temp"].double {
                cell.tempLabel.text = convertTemp(temp: temp, from: .kelvin, to: .celsius)
            }
            
            if let humid = searchResults[indexPath.row]["main"]["humidity"].double {
                cell.humidLabel.text = "\(humid)%"
            }
            
            if let windSpeed = searchResults[indexPath.row]["wind"]["speed"].double {
                cell.windLabel.text = "\(windSpeed) mph"
            }
            
            if let cloud = searchResults[indexPath.row]["weather"][indexPath.row]["description"].string {
                cell.cloudLabel.text = cloud
            }
            
            if let cloudIcon = searchResults[indexPath.row]["weather"][indexPath.row]["icon"].string {
                cell.tempImage.downloadImage(from: cloudIcon.imageString())
            }
            
            
            return cell
        }
           return UITableViewCell()
       }
    @IBAction func didPressBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

let imageCache = NSCache<NSString, UIImage>()

extension UIImageView {

    func downloadImage(from imgURL: String!) {
        let url = URLRequest(url: URL(string: imgURL)!)

        // set initial image to nil so it doesn't use the image from a reused cell
        image = nil

        // check if the image is already in the cache
        if let imageToCache = imageCache.object(forKey: imgURL! as NSString) {
            self.image = imageToCache
            return
        }

        // download the image asynchronously
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }

            DispatchQueue.main.async {
                // create UIImage
                let imageToCache = UIImage(data: data!)
                // add image to cache
                imageCache.setObject(imageToCache!, forKey: imgURL! as NSString)
                self.image = imageToCache
            }
        }
        task.resume()
    }
}

extension ViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchResults.removeAll()
        
        guard let textToSearch = searchBar.text, !textToSearch.isEmpty else {
            return
        }
        
        print("after every text gets changed")
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.output), userInfo: searchText, repeats: false)
    }
    
    func fetchResults(for text: String) {
        print("Text Searched: \(text)")
        apiFetcher.search(searchText: text, completionHandler: {
            [weak self] results, error in
            if case .failure = error {
                return
            }
            
            guard let results = results, !results.isEmpty else {
                return
            }
            print(results)
            self?.searchResults = results
        })
    }

}
