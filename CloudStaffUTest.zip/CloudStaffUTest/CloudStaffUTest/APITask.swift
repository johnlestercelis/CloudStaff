//
//  APITask.swift
//  TestCloudStaff
//
//  Created by John Lester Celis on 3/6/20.
//  Copyright © 2020 John Lester Celis. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

enum NetworkError: Error {
    case failure
    case success
}

class APITask {
    private let apiKey = "4a510884276a1d1159cfcd2a162fa436"
    func search(searchText: String, completionHandler: @escaping ([JSON]?, NetworkError) -> ()) {
        
        if searchText.isNumber {
            if let url = URLComponents(queryItems: [URLQueryItem(name: "zip", value: searchText),
                                                    URLQueryItem(name: "appid", value: apiKey)]).url {
                print(url)
                Alamofire.request(url).responseJSON() { response in
                     if response.result.error == nil {
                        let swiftyJSON = JSON(response.value!)
                        if let result = swiftyJSON.array {
                            print(result)
                         }
                     } else {
                        completionHandler(nil, .failure)
                     }
                }
            }
        } else {
            if let url = URLComponents(queryItems: [URLQueryItem(name: "q", value: searchText),
                                                    URLQueryItem(name: "appid", value: apiKey)]).url {
                print(url)
                Alamofire.request(url).responseJSON() { response in
                    
                    switch response.result {
                    case .success(let value):
                        let json = JSON(value)
                        completionHandler([json], .success)

                    case .failure(let error):
                        print(error)
                        completionHandler(nil, .failure)

                    }
                }
            }
        }
    }
}


