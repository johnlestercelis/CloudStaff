//
//  Extensions.swift
//  TestCloudStaff
//
//  Created by John Lester Celis on 3/6/20.
//  Copyright © 2020 John Lester Celis. All rights reserved.
//

import Foundation
import UIKit

extension String  {
    var isNumber: Bool {
        return !isEmpty && rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
    
    func imageString() -> String {
        return "http://openweathermap.org/img/w/\(self).png"
    }
}

extension URLComponents {
    init(scheme: String = "http",
         host: String = "api.openweathermap.org",
         path: String = "/data/2.5/weather",
         queryItems: [URLQueryItem]) {
        self.init()
        self.scheme = scheme
        self.host = host
        self.path = path
        self.queryItems = queryItems
    }
}

extension Array {
    mutating func move(at index: Index, to newIndex: Index) {
        insert(remove(at: index), at: newIndex)
    }
}

extension UITableViewController {
    func isKeyPresentInUserDefaults(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
}
